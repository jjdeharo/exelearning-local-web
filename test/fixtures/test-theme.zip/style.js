// Test theme JS
console.log('[Test Theme] loaded');
